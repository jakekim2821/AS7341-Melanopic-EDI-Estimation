# AS7341 Melanopic SPD Estimation

This repository contains a Python implementation of a **channel-total-preserving
piecewise-linear spectral estimation method** for estimating 1-nm spectral data
from the eight visible spectral channels (F1-F8) of the AS7341 sensor.

## Purpose

The CIE S 026 melanopic sensitivity function is defined at fine wavelength
intervals, whereas the AS7341 provides only a small number of spectral channels.
This project tests whether the limited channel information can be converted into
an estimated 1-nm spectral power distribution (SPD) for melanopic calculations.

## Method

The nominal wavelength ranges used in this model are:

| Channel | Range (nm) | Center (nm) |
|---|---:|---:|
| F1 | 405-425 | 415 |
| F2 | 435-455 | 445 |
| F3 | 470-490 | 480 |
| F4 | 505-525 | 515 |
| F5 | 545-565 | 555 |
| F6 | 580-600 | 590 |
| F7 | 620-640 | 630 |
| F8 | 670-690 | 680 |

The SPD values at the eight center wavelengths are treated as unknowns.
Adjacent center values are connected by linear interpolation. The eight unknown
values are determined by solving eight constraints:

`sum(estimated SPD over each Fi wavelength range) = original Fi channel total`

Therefore, the estimated spectrum is continuous and preserves the total value of
every modeled channel. The estimated 1-nm SPD is then combined with the
melanopic sensitivity function for numerical integration.

## D65 validation

For validation, a known 1-nm D65 spectrum is first compressed into the eight
modeled channel totals. The program then reconstructs an estimated 1-nm spectrum
using only those eight totals and compares the resulting normalized melanopic
integral with the reference calculation.

The exact validation value may depend on the final data and implementation
version. Use the program output and `results/D65_validation.csv` when reporting
the final numerical error in a manuscript.

## Files

- `AS7341_SPD_estimation.py` - main estimation and validation program
- `data/D65_SPD.csv` - D65 spectral data used by the program
- `data/Smel_CIE_S026.csv` - melanopic sensitivity values used by the program
- `results/D65_validation.csv` - generated wavelength-by-wavelength validation output
- `requirements.txt` - Python dependency

## Run

```bash
python -m pip install -r requirements.txt
python AS7341_SPD_estimation.py
```

## Important limitation

This code models each AS7341 channel using a nominal wavelength interval and a
channel total. A real AS7341 channel has its own wavelength-dependent spectral
responsivity. Therefore, this program should be described as a simplified
spectral estimation model rather than a full physical reconstruction of the
sensor response.

## Suggested manuscript wording

> The source code used for channel-total-preserving spectral estimation and
> error validation is publicly available in the accompanying repository.

## Citation

If this repository is archived with Zenodo, replace this section with the DOI
and the final citation for the archived release.
